# MAmmoTH 900문항·ECD 800문항 누수 검사 결과

작성일: 2026-11-19 (한국시간)

## 검사 대상

| 구분 | 문항 수 |
|---|---:|
| MAmmoTH 신규 학습 후보 | 900 |
| ECD 신규 학습 후보 | 800 |
| 합계 | 1,700 |

비교 기준은 MMMU·MMMU-Pro 평가 데이터 16,740행이다. 평가 구성 간 중복을 포함한 비교 행 수이다.

## 검사 방법

이미지 해시·질문 문자열 대조, 질문 의미 유사도 검색, MMMU-Pro vision 문항 OCR 검색을 진행했다. 검색된 초기 후보는 이미지·질문으로 직접 대조했다. OCR 경고 19건은 원본에서 질문·도형·선택지를 확인하고 질문을 보완했다.

19건 모두 동일 질문이 기존 MMMU 텍스트 자료에 포함됨을 확인했다. 동일 입력 1,700문항·동일 모델로 이미 계산된 평가→학습 Top-5 점수 95행을 재사용하여 OCR 기준 0.60으로 재검토했다. 18건은 최고점도 기준 미만이었고, 나머지 1건에서 추가 후보 1쌍이 나왔다. 추가 후보는 제공 학습 질문·선택지와 평가 원본을 대조하여 다른 문제로 판정했다. 해당 학습 이미지는 제공 ZIP에 없어 시각 대조를 수행했다고 기록하지 않았다.

이는 자동 OCR 성공이나 모델 재실행이 아니라 원본 수동 확인 및 기존 점수를 이용한 보완 검토이다. 보완한 질문과 학습 질문의 문자열 포함 대조도 추가로 실행했으며 일치 0건이었다.

## 결과

| 항목 | 결과 |
|---|---|
| 초기 후보 149쌍 | 모두 다른 문제 |
| OCR 경고 19건 | 원본 수동 확인 완료 |
| 보완 검토 추가 후보 1쌍 | 다른 문제 |
| 누수 확정 | 0쌍 |
| 미해결 후보 | 0쌍 |

**최종 결론: 검사 범위에서 MAmmoTH 900문항·ECD 800문항과 MMMU·MMMU-Pro 평가 데이터 사이의 누수는 탐지되지 않았다.**

36번 후보(mammoth_1183966 / test_Math_474)는 공통 기하 구조와 수치 관계가 있으나 주어진 조건과 구하는 값이 다르고, 복제·변형을 입증할 근거가 확인되지 않아 C의 최종 판단을 반영하여 다른 문제로 판정했다.

보완 검토의 추가 후보는 mammoth_7890463 / test_Architecture_and_Engineering_473이다. 학습은 직각삼각형의 코사인 계산, 평가는 위성측점에서 관측한 방향과 거리를 이용한 측량각 계산으로 조건과 목표가 다르다.

## 근거와 재현 기준

- 초기 149쌍: reviewed.csv / reviewed.jsonl
- OCR 19건: ocr_manual_review.jsonl / evidence/ocr19/
- 기존 검색 점수 95행: ocr_manual_top5_evidence.jsonl
- 추가 1쌍: ocr_supplement_reviewed.csv / ocr_supplement_reviewed.jsonl
- 최종 집계: final_leakage_summary.json
- 입력 자료의 commit·SHA256: input_provenance.json
- 평가 파일별 revision·행 수: benchmark_coverage.jsonl
- B 입력 commit: dc5d42caf69630a9d785259a38ad77aabc949867
- A 전달 자료 commit: a61adb899d3c2274ba98cba7a360c5b4f333979f
- 모델: sentence-transformers/all-MiniLM-L6-v2
- 모델 commit: 1110a243fdf4706b3f48f1d95db1a4f5529b4d41
- 원문 검색 기준 0.70 / OCR 및 보완 검토 기준 0.60

## 범위

결론은 해당 1,700문항과 문서화한 검색·검수 범위에 한정한다. 1,700문항 전체를 전수 수동 대조했다는 의미는 아니다. 기존 완료된 SFT1 누수 검사와 별도이며, 기존 검사를 재수행하지 않았다.

screening_summary.json은 자동 검색 당시 집계이다. ocr_quality_flags.jsonl은 처음 발생한 OCR 경고 목록으로, 현재 미해결 목록이 아니다. 최종 상태는 final_leakage_summary.json을 따른다.
