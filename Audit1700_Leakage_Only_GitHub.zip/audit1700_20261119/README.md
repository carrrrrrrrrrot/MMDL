# Audit1700 누수 검사 공유 자료

**검사 범위에서 MMMU·MMMU-Pro 평가 데이터 누수 미탐지.**

| 파일 | 내용 |
|---|---|
| REPORT.md | 검사 범위·방법·결과 |
| HANDOFF_A_B.md | 팀 공유용 문구 |
| final_leakage_summary.json | 최종 결과 집계 |
| reviewed.csv / reviewed.jsonl | 초기 149쌍의 판정과 근거 |
| ocr_manual_review.jsonl | OCR 경고 19건의 원본 검수 기록 |
| ocr_manual_top5_evidence.jsonl | 해당 19건의 기존 검색 점수 95행 |
| ocr_supplement_reviewed.csv/jsonl | 추가 후보 1쌍의 판정 |
| item_screening_status.jsonl | 1,700문항 ID별 누수 검사 상태 |
| input_provenance.json | 입력 commit·SHA256 |
| benchmark_coverage.jsonl | 평가 파일별 revision·처리 행 수 |
| evidence/ | 검수 근거 이미지 |
| SHA256SUMS.txt | 파일 무결성 확인용 해시 |

## GitHub 업로드

압축을 풀고 audit1700_20261119 폴더를 c/shared 브랜치 루트에 업로드한다. 기존 SFT1 파일은 수정하지 않는다. 이번 패키지가 이전 업로드용 패키지를 대체한다. 이전 패키지의 quality_followup.jsonl을 이미 GitHub에 올렸다면 이번 공유 구성에서는 제거한다.

권장 커밋 메시지:

```text
docs(c): report no leakage detected in MAmmoTH900 and ECD800 audit
```

원격 업로드는 아직 수행하지 않았다. Colab 전체 재실행은 필요하지 않다.
