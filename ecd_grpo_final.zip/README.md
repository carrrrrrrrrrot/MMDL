# B용 ECD GRPO 첫 파일럿

승인 문항 104개. JSONL과 images/를 /data/chaewon/mmdl_grpo_data/ecd_10k/ 아래에 풉니다. SFT 어댑터 SHA256을 확인한 공통 부모에서 최대 20 optimizer steps, 문항당 rollout 4개로 시작합니다. 이미지 경로와 숫자 보상 처리를 확인하고, 문항별 4개 rollout의 보상이 모두 같은 비율을 기록합니다.

MMMU·MMMU-Pro 기준 16,740행을 대조해 0건을 제외했습니다. 검사 방법과 미검사 범위는 ecd_grpo_review_summary.json에 기록했습니다.
