# SFT1 학습 데이터 누수 검수 최종 결과

SFT1 학습 문항 12,278개와 MMMU 11,550행 및 MMMU-Pro 5,190행을 비교했다. 자동 검사에서 파일·RGB 픽셀 SHA256 정확 일치 0쌍, 정규화 질문 정확 일치 6쌍, dHash 해밍 거리 4 이하 382쌍을 확인했다. 전체 후보 388쌍은 고유 학습 문항 97개에 해당한다.

후보 388쌍을 모두 검토했다. 실제 SFT1 입력 기준 별개 388쌍, 판정 보류 0쌍, 동일 문항 또는 동일 이미지 재사용 확인 0쌍이다. 질문 일치 6쌍은 학습의 바이올린 사진과 평가의 신경 시냅스 도식이 서로 달랐다.

기존 보류 26쌍은 Geo170K의 793.png와 1218.png를 각각 13쌍씩 참조했다. Geo170K 저자 배포본의 images/geoqa_plus, LLaVA-OneVision Geo170K QA 재배포본, A가 공유한 학습 PNG가 각 ID에서 바이트 단위로 일치했다. 두 PNG는 모든 픽셀값이 0이며 평가 이미지는 시각 내용이 있어 별개로 판정했다. 학습 이미지 2장은 데이터 품질 이슈로 기록한다. Geo170K 배포 이전에 검은 이미지가 만들어진 원인은 확인하지 못했다.

최종 판정 CSV에는 후보별 학습·평가 ID, 자동 검사 근거, 최종 판정, 판정 사유를 담았다. 자동 검사에 포함된 범위에서의 결과이며 질문 OCR, 바꿔 쓴 질문의 의미 유사도, 심한 크롭·합성으로 인한 이미지 변형은 검사 범위에 포함되지 않았다.

- [Geo170K 저자 배포 이미지](https://huggingface.co/datasets/Luckyjhg/Geo170K/blob/main/images.zip)
- [LLaVA-OneVision Geo170K QA 재배포본](https://huggingface.co/datasets/lmms-lab/LLaVA-OneVision-Data/blob/main/geo170k%28qa%29/train-00000-of-00001.parquet)
